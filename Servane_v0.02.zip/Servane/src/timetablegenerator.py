#
# Script pour générer l'emploi du temps de l'application Servane
# On utilise une classe tkinter pour créer une fenêtre à part

from tkinter import *
from datetime import datetime

class TimeTable(Tk):
    '''
    
    '''

    def __init__(self) -> None:
        Tk.__init__(self)